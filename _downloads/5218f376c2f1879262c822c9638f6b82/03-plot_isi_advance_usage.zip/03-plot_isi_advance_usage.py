"""
IntraSiteInterpolation advance usage
====================================

Interpolation cannot create information: a handful of samples cannot be interpolated into thousands. ISI measures,
for every class it over-samples, how much of the class variance interpolation keeps, and warns when balancing needs more
synthetic samples than is safe. ISI only interpolates; ``SiteBalancedResampler`` combines it with under-sampling: it
limits interpolation (``max_amplification``) and closes the remaining imbalance with an under-sampler, so both meet in
the middle.
"""

# %%
# Imports
# -------

import matplotlib.pyplot as plt
import numpy as np
import pandas as pd
import seaborn as sns
import sklearn
from imblearn.pipeline import Pipeline
from sklearn.linear_model import LogisticRegression
from sklearn.model_selection import StratifiedKFold, cross_validate

from uniharmony import verbosity
from uniharmony.datasets import make_multisite_classification
from uniharmony.interpolation import IntraSiteInterpolation, SiteBalancedResampler


sns.set_theme(style="whitegrid")
verbosity("warning")

X, y, sites = make_multisite_classification(
    n_sites=3,
    n_samples=[400, 400, 400],
    n_features=5,
    balance_per_site=[[0.8, 0.2], [0.5, 0.5], [0.3, 0.7]],
    random_state=23,
)

# %%
# How much interpolation is safe?
# -------------------------------
#
# ISI only over-samples and never removes a sample. For every class it over-samples, it measures the ratio
# between the variance of the synthetic and of the real samples (``variance_ratio``, ``rho``) and derives the safe
# amplification: the number of synthetic samples per real sample that keeps at least 80% of the class variance
# (``variance_tolerance=0.2``). If balancing needs more, ISI warns. ``summary()`` reports it for every site and class.

isi = IntraSiteInterpolation(interpolator="smote", random_state=42)
X_bal, y_bal = isi.fit_resample(X, y, sites=sites)
isi.summary().round(2)

# %%
# The same diagnostic is available without resampling, to check a data set before choosing a method.

isi.estimate_safe_amplification(X, y, sites=sites).round(2)

# %%
# Combining interpolation with under-sampling
# -------------------------------------------
#
# ``SiteBalancedResampler`` limits the amplification of every class to ``max_amplification`` and under-samples the
# larger classes of the site (with ClusterCentroids by default) to meet the smaller ones. Different caps give different
# trade-offs: ``None`` is ISI alone, ``"auto"`` (default) uses the safe amplification, ``0`` only under-samples.

rows = []
for cap in [None, "auto", 1.0, 0]:
    sbr = SiteBalancedResampler(IntraSiteInterpolation("smote", random_state=42), max_amplification=cap, random_state=42)
    _, y_cap = sbr.fit_resample(X, y, sites=sites)
    report = sbr.summary()
    rows.append(
        {
            "max_amplification": str(cap),
            "real samples kept": int((report.n_real - report.n_removed).sum()),
            "synthetic samples": int(report.n_created.sum()),
        }
    )
df = pd.DataFrame(rows).melt(id_vars="max_amplification", var_name="samples", value_name="n")
plt.figure(figsize=[10, 6])
plt.title("Composition of the balanced training set")
sns.barplot(df, x="max_amplification", y="n", hue="samples")

# %%
# Global balancing
# ----------------
#
# ``balance_strategy="global_max"`` balances every site towards the largest class of any site, so sites also get
# similar sizes. Small sites then need much more interpolation, which the variance diagnostic may flag.

isi_global = IntraSiteInterpolation(balance_strategy="global_max", random_state=42)
_, y_global = isi_global.fit_resample(X, y, sites=sites)
print(f"Global target count: {isi_global.target_count_}, per site: {isi_global.target_counts_}")

# %%
# Choosing the samplers
# ---------------------
#
# Any imblearn over-sampler can be used to interpolate, and any under-sampler that selects real samples and accepts a
# target count per class can be used by ``SiteBalancedResampler``.

sbr_nm = SiteBalancedResampler(
    IntraSiteInterpolation(interpolator="borderline-smote"), undersampler="nearmiss", max_amplification=1.0
)
X_nm, y_nm = sbr_nm.fit_resample(X, y, sites=sites)
print(sbr_nm.target_counts_)

# %%
# Covariates
# ----------
#
# Covariates restrict who is interpolated with whom: synthetic samples are interpolated between samples of the same
# class, site and covariate stratum (here sex and three age bins), and are spread over the strata like the real samples
# of their class.

rng = np.random.default_rng(54)
sex = rng.integers(0, 2, len(y))
age = rng.normal(50, 10, len(y))
isi_cov = IntraSiteInterpolation(n_bins_cont_cov=3, random_state=42)
X_cov, y_cov = isi_cov.fit_resample(X, y, sites=sites, categorical_covariates=sex, continuous_covariates=age)

# The covariates of the real samples kept can be recovered with ``sample_indices_``
real = ~isi_cov.is_synthetic_
sex_kept = sex[isi_cov.sample_indices_[real]]

# %%
# Use on training data only
# -------------------------
#
# ISI must only see the training folds. Put it in an ``imblearn`` pipeline, with the sites as a column of a DataFrame
# named by ``site_column``: the folds split the sites with the features, and ISI returns the site column of the
# resampled data (synthetic samples included), so a harmonizer could follow it (see "Using UniHarmony in pipelines").
# The classifier must not see the site column, so a ``ColumnTransformer`` drops it here.

from sklearn.compose import make_column_transformer

df = pd.DataFrame(X, columns=[f"feature_{j}" for j in range(X.shape[1])]).assign(site=sites)
pipe = Pipeline(
    [
        ("isi", IntraSiteInterpolation(site_column="site", random_state=0)),
        ("drop_site", make_column_transformer(("drop", ["site"]), remainder="passthrough")),
        ("clf", LogisticRegression()),
    ]
)
cv = StratifiedKFold(5, shuffle=True, random_state=0)
scores = cross_validate(pipe, df, y, cv=cv, scoring="roc_auc")
print(f"CV AUC with ISI inside the folds: {scores['test_score'].mean():.3f}")

# %%
# The ``sites`` keyword also works with scikit-learn metadata routing, as long as no later step needs the sites of
# the synthetic samples:

with sklearn.config_context(enable_metadata_routing=True):
    pipe = Pipeline([("isi", IntraSiteInterpolation(random_state=0)), ("clf", LogisticRegression())])
    scores = cross_validate(pipe, X, y, cv=cv, params={"sites": sites}, scoring="roc_auc")
print(f"CV AUC (metadata routing): {scores['test_score'].mean():.3f}")

###############################################################################
# .. admonition:: Take-home message
#
#    ISI balances every site by interpolation and tells you when a class is too small to be balanced without losing
#    its variance. ``SiteBalancedResampler`` limits interpolation (``max_amplification``) and under-samples the rest.
